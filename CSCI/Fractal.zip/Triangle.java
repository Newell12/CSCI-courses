//Written by Liam Newell(newel183umn.edu)
import static java.lang.Math.PI;
import java.awt.*;
public class Triangle{ //Triangle Class that represents a Triangle shape
  private double xpos; //x-position of Triangle in bottom left corner
  private double ypos; //y-position of Triangle in bottom left corner
  private double width; //width of Triangle
  private double height; //height of Triangle
  private Color color; //color of Triangle

  public Triangle(double x, double y, double w, double h){ //Constructor for Triangle class
    xpos = x;
    ypos = y;
    width = w;
    height = h;
  }

  public double calculatePerimeter(){ //Method that Calculates the Perimeter of the Triangle
    return width + width +width;
  }

  public double calculateArea(){ //Method that calculates the Area of the Triangle
    return (width*height)/2;
  }

  public void setColor(Color c1){ //Method that sets the color of the Triangle to a new color
    color = c1;
  }

  public void setPos(double x1, double y1){ //Method that sets the position of the Triangle by giving a new xposition and yposition
    xpos = x1;
    ypos = y1;
  }

  public void setHeight(double h1){ //Method that sets the height of the Triangle to a new height
    height = h1;
  }

  public void setWidth(double w1){ //Method that sets the width of the Triangle to a new width
    width = w1;
  }

  public Color getColor(){ //Method that sets the color of the Triangle to a new color
    return color;
  }

  public double getXPos(){ //Method that returns the current xposition of the Triangle
    return xpos;
  }

  public double getYPos(){ //Method that returns the current yposition of the Triangle
    return ypos;
  }

  public double getHeight(){ //Method that returns the current height of the Triangle
    return height;
  }

  public double getWidth(){ //Method that returns the current width of the Triangle
    return width;
  }
}
