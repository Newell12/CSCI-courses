//Written by Liam Newell(newel183umn.edu)
import static java.lang.Math.PI;
import java.awt.*;
public class Rectangle{ //Rectangle Class that represents a Rectangle shape
  private double xpos; //x-position of Rectangle in upper left corner
  private double ypos; //y-position of Rectangle in upper left corner
  private double width; //width of Rectangle
  private double height; //height of Rectangle
  private Color color; //color of rectangles

  public Rectangle(double x, double y, double w, double h){ //Constructor for Rectangle class
    xpos = x;
    ypos = y;
    width = w;
    height = h;
  }

  public double calculatePerimeter(){ //Method that Calculates the Perimeter of the Rectangle
    return width + width + height + height;
  }

  public double calculateArea(){ //Method that calculates the Area of the Rectangle
    return (width*height);
  }

  public void setColor(Color c1){ //Method that sets the color of the Rectangle to a new color
    color = c1;
  }

  public void setPos(double x1, double y1){ //Method that sets the position of the Rectangle by giving a new xposition and yposition
    xpos = x1;
    ypos = y1;
  }

  public void setHeight(double h1){ //Method that sets the height of the Rectangle to a new height
    height = h1;
  }

  public void setWidth(double w1){ //Method that sets the width of the Rectangle to a new width
    width = w1;
  }

  public Color getColor(){ //Method that sets the color of the Rectangle to a new color
    return color;
  }

  public double getXPos(){ //Method that returns the current xposition of the Rectangle
    return xpos;
  }

  public double getYPos(){ //Method that returns the current yposition of the Rectangle
    return ypos;
  }

  public double getHeight(){ //Method that returns the current height of the Rectangle
    return height;
  }

  public double getWidth(){ //Method that returns the current width of the Rectangle
    return width;
  }
}
