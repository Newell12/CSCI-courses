Members: Liam Newell (newel183@umn.edu)
No Partner

Compiling and Running: I have been compiling and running the program out of Windows Powershell.
To start type javac FractalDrawer.java and enter then next java FractalDrawer and enter.
This will prompt a statement asking for which shape of fractal to make.
Enter triangle, circle or rectangle to produce a fractal of each shape.

Notes on Running: Sometimes when the graphics load in they take a second or they may appear only partially complete at first.
I have found that this is solved by minimizing the graphics screen and then reopening it.

Assumptions: Assume that all triangles are isoceles.

Additional Features: N/A

Known Bugs: N/A

Outside Sources: None

Rules Statement:
I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ’Academic Integrity - Course Policy’ section of the course syllabus.
Liam Newell
